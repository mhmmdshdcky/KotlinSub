fun main() {
    val stringNumber = "23"
    val intNumber = 3

    print(intNumber + stringNumber.toInt())
}