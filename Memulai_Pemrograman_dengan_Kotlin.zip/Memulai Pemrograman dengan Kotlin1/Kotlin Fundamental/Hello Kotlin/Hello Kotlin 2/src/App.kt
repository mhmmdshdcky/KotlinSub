// main function
fun main() {
    val name = "Dicky"

    print("Hello my name is ")
    println(name)
    print(if (true) "Always true" else "Always false")
}
/*
   output:
       Hello my name is Alfian
       Always true
*/